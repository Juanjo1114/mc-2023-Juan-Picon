import java.lang.Math;

public class Taller12 {
   
    // Función para calcular la serie de Taylor de e^-x
    public static double taylor_exp(double x, int order) {
        double result = 0;
        for (int n = 0; n <= order; n++) {
            result += Math.pow(-1, n)*Math.pow(x, n)/factorial(n);
        }
        return result;
    }
   
    // Función para calcular el factorial de un número
    public static int factorial(int n) {
        if (n == 0) {
            return 1;
        } else {
            return n*factorial(n-1);
        }
    }
   
    public static void main(String[] args) {
       
        // Datos de entrada
        double xi = 0.45;
        double xi1 = 0.455;
        double h = 0.005;

        // Cálculo de la función en xi
        double fxi = Math.exp(-xi);

        // Estimación de la función en xi1 para cada orden de la serie de Taylor
        double estimation = 0;
        for (int order = 0; order <= 15; order++) {
            double estAnt = estimation;
            estimation += Math.pow(-1, order)*fxi*Math.pow(h, order)/factorial(order);
            /*for (int n = 1; n <= order; n++) {
                estimation += taylor_exp(xi, order-n)*Math.pow(h, n)/factorial(n);
            }*/
            // Cálculo del error aproximado relativo porcentual
            double error = Math.abs((estimation - estAnt)/estimation)*100;

            // Imprimir resultados
            System.out.println("Orden " + order + ": Estimación = " + estimation + ", Error relativo porcentual = " + error + "%");
        }
    }
}